# Komida Backend

Backend server for Komida, built with Bun and Hono.

## Getting Started

To start the development server:

```bash
bun run dev
```

## API

- `GET /` - Welcome message
- `GET /health` - Health check
